import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import PacientesPage from "./pages/PacientesPage";
import MedicosPage from "./pages/MedicosPage";
import CitasPage from "./pages/CitasPage";
import ConsultoriosPage from "./pages/ConsultoriosPage";

import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  return (
    <Router>
      {/* Navbar con Bootstrap */}
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">Citas Médicas</Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <Link className="nav-link" to="/pacientes">Pacientes</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/medicos">Médicos</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/citas">Citas</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/consultorios">Consultorios</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Rutas */}
      <div className="container mt-4">
        <Routes>
          <Route path="/pacientes" element={<PacientesPage />} />
          <Route path="/medicos" element={<MedicosPage />} />
          <Route path="/citas" element={<CitasPage />} />
          <Route path="/consultorios" element={<ConsultoriosPage />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
