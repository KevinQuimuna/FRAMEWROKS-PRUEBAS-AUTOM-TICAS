import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

interface Paciente {
  id: number;
  nombre: string;
  apellido: string;
  fechaNacimiento: string;
  email: string;
}

const PacientesPage: React.FC = () => {
  const [pacientes, setPacientes] = useState<Paciente[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<Paciente>({
    id: 0,
    nombre: "",
    apellido: "",
    fechaNacimiento: "",
    email: "",
  });
  const [open, setOpen] = useState<boolean>(false);

  useEffect(() => {
    const fetchPacientes = async () => {
      try {
        const response = await fetch("http://localhost:9090/api/pacientes");
        if (!response.ok) throw new Error("Error al cargar los pacientes. Intenta nuevamente.");
        const data: Paciente[] = await response.json();
        setPacientes(data);
      } catch (error) {
        setError("Error al cargar los pacientes. Intenta nuevamente.");
      }
    };

    fetchPacientes();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nombre || !formData.apellido || !formData.email || !formData.fechaNacimiento) {
      setError("Todos los campos son obligatorios");
      return;
    }

    try {
      const response = await fetch("http://localhost:9090/api/pacientes", {
        method: formData.id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) throw new Error("Error al guardar el paciente. Intenta nuevamente.");

      const newPaciente: Paciente = await response.json();
      setPacientes(formData.id ? pacientes.map(p => (p.id === formData.id ? newPaciente : p)) : [...pacientes, newPaciente]);
      setError(null);
      setFormData({ id: 0, nombre: "", apellido: "", fechaNacimiento: "", email: "" });
      setOpen(false);
    } catch (error) {
      setError("Error al guardar el paciente. Intenta nuevamente.");
    }
  };

  const handleEdit = (paciente: Paciente) => {
    setFormData(paciente);
    setOpen(true);
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Lista de Pacientes</h2>

      {error && <div className="alert alert-danger">{error}</div>}

      <div className="d-flex justify-content-between mb-3">
        <h4>Pacientes</h4>
        <button className="btn btn-primary" onClick={() => setOpen(true)}>Agregar Paciente</button>
      </div>

      <ul className="list-group">
        {pacientes.map((paciente) => (
          <li key={paciente.id} className="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <strong>{paciente.nombre} {paciente.apellido}</strong> - {paciente.email} - {paciente.fechaNacimiento}
            </div>
            <button className="btn btn-warning btn-sm" onClick={() => handleEdit(paciente)}>Editar</button>
          </li>
        ))}
      </ul>

      {open && (
        <div className="mt-4">
          <h3 className="mb-3">{formData.id ? "Editar Paciente" : "Agregar Paciente"}</h3>
          <form onSubmit={handleSubmit} className="card card-body shadow p-4">
            <div className="mb-3">
              <label className="form-label">Nombre</label>
              <input type="text" name="nombre" value={formData.nombre} onChange={handleChange} className="form-control" />
            </div>
            <div className="mb-3">
              <label className="form-label">Apellido</label>
              <input type="text" name="apellido" value={formData.apellido} onChange={handleChange} className="form-control" />
            </div>
            <div className="mb-3">
              <label className="form-label">Fecha de Nacimiento</label>
              <input type="date" name="fechaNacimiento" value={formData.fechaNacimiento} onChange={handleChange} className="form-control" />
            </div>
            <div className="mb-3">
              <label className="form-label">Email</label>
              <input type="email" name="email" value={formData.email} onChange={handleChange} className="form-control" />
            </div>
            <div className="d-flex gap-2">
              <button type="submit" className="btn btn-success">{formData.id ? "Actualizar" : "Agregar"}</button>
              <button type="button" className="btn btn-secondary" onClick={() => setOpen(false)}>Cancelar</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default PacientesPage;