import React, { useEffect, useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';

interface Cita {
  id: number;
  pacienteId: number;
  medicoId: number;
  fecha: string;
  hora: string;
  consultorioId: number; // Cambiado a consultorioId
}

interface Paciente {
  id: number;
  nombre: string;
}

interface Medico {
  id: number;
  nombre: string;
}

interface Consultorio {
  id: number;
  numero: string;
  piso: number;
}

const CitasPage: React.FC = () => {
  const [citas, setCitas] = useState<Cita[]>([]);
  const [pacientes, setPacientes] = useState<Paciente[]>([]);
  const [medicos, setMedicos] = useState<Medico[]>([]);
  const [consultorios, setConsultorios] = useState<Consultorio[]>([]);
  const [modalMode, setModalMode] = useState<"crear" | "editar" | "borrar" | null>(null);
  const [selectedCita, setSelectedCita] = useState<Cita | null>(null);
  const [nuevaCita, setNuevaCita] = useState<Cita>({
    id: 0,
    pacienteId: 0,
    medicoId: 0,
    fecha: "",
    hora: "",
    consultorioId: 0, // Cambiado a consultorioId
  });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    obtenerCitas();
    obtenerPacientes();
    obtenerMedicos();
    obtenerConsultorios();
  }, []);

  const obtenerCitas = () => {
    axios.get("http://localhost:9090/api/citas")
      .then(response => setCitas(response.data))
      .catch(error => console.error("Error al obtener citas", error));
  };

  const obtenerPacientes = () => {
    axios.get("http://localhost:9090/api/citas/pacientes")
      .then(response => setPacientes(response.data))
      .catch(error => console.error("Error al obtener pacientes", error));
  };

  const obtenerMedicos = () => {
    axios.get("http://localhost:9090/api/citas/medicos")
      .then(response => setMedicos(response.data))
      .catch(error => console.error("Error al obtener médicos", error));
  };

  const obtenerConsultorios = () => {
    axios.get("http://localhost:9090/api/consultorios")
      .then(response => setConsultorios(response.data))
      .catch(error => console.error("Error al obtener consultorios", error));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (modalMode === "editar" && selectedCita) {
      setSelectedCita({ ...selectedCita, [name]: value });
    } else if (modalMode === "crear") {
      setNuevaCita({ ...nuevaCita, [name]: value });
    }
  };

  const handleSave = () => {
    if (!nuevaCita.pacienteId || !nuevaCita.medicoId || !nuevaCita.fecha || !nuevaCita.hora || !nuevaCita.consultorioId) {
      setError("Todos los campos son obligatorios");
      return;
    }

    if (modalMode === "editar" && selectedCita) {
      axios.put(`http://localhost:9090/api/citas/${selectedCita.id}`, selectedCita)
        .then(() => {
          obtenerCitas();
          setModalMode(null);
          setError(null);
        })
        .catch(error => setError("Error al actualizar la cita"));
    } else if (modalMode === "crear") {
      axios.post("http://localhost:9090/api/citas", nuevaCita)
        .then(() => {
          obtenerCitas();
          setModalMode(null);
          setError(null);
        })
        .catch(error => setError("Error al crear la cita"));
    }
  };

  const handleDelete = () => {
    if (selectedCita) {
      axios.delete(`http://localhost:9090/api/citas/${selectedCita.id}`)
        .then(() => {
          obtenerCitas();
          setModalMode(null);
          setError(null);
        })
        .catch(error => setError("Error al eliminar la cita"));
    }
  };

  return (
    <div className="container mt-4">
      <h1 className="mb-4">Citas Médicas</h1>

      <button className="btn btn-primary mb-3" onClick={() => setModalMode("crear")}>
        Nueva Cita
      </button>

      {error && <div className="alert alert-danger">{error}</div>}

      <table className="table table-bordered table-striped">
        <thead className="thead-dark">
          <tr>
            <th>ID</th>
            <th>Paciente</th>
            <th>Médico</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Consultorio</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {citas.map(cita => (
            <tr key={cita.id}>
              <td>{cita.id}</td>
              <td>{pacientes.find(p => p.id === cita.pacienteId)?.nombre}</td>
              <td>{medicos.find(m => m.id === cita.medicoId)?.nombre}</td>
              <td>{cita.fecha}</td>
              <td>{cita.hora}</td>
              <td>
                {consultorios.find(c => c.id === cita.consultorioId)?.numero} - Piso {
                  consultorios.find(c => c.id === cita.consultorioId)?.piso
                }
              </td>
              <td className="d-flex justify-content-start">
                <button
                  className="btn btn-success me-2"
                  onClick={() => { setSelectedCita(cita); setModalMode("editar"); }}
                >
                  Editar
                </button>
                <button
                  className="btn btn-danger"
                  onClick={() => { setSelectedCita(cita); setModalMode("borrar"); }}
                >
                  Borrar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* MODAL PARA CREAR/EDITAR */}
      {modalMode && (modalMode === "crear" || modalMode === "editar") && (
        <div className="modal show d-block" tabIndex={-1} role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{modalMode === "crear" ? "Nueva Cita" : "Editar Cita"}</h5>
                <button type="button" className="close" onClick={() => setModalMode(null)}>×</button>
              </div>
              <div className="modal-body">
                <select
                  className="form-control mb-2"
                  name="pacienteId"
                  value={modalMode === "crear" ? nuevaCita.pacienteId : selectedCita?.pacienteId}
                  onChange={handleChange}
                >
                  <option value={0}>Seleccione un paciente</option>
                  {pacientes.map(paciente => (
                    <option key={paciente.id} value={paciente.id}>{paciente.nombre}</option>
                  ))}
                </select>
                <select
                  className="form-control mb-2"
                  name="medicoId"
                  value={modalMode === "crear" ? nuevaCita.medicoId : selectedCita?.medicoId}
                  onChange={handleChange}
                >
                  <option value={0}>Seleccione un médico</option>
                  {medicos.map(medico => (
                    <option key={medico.id} value={medico.id}>{medico.nombre}</option>
                  ))}
                </select>
                <input
                  type="date"
                  className="form-control mb-2"
                  name="fecha"
                  value={modalMode === "crear" ? nuevaCita.fecha : selectedCita?.fecha}
                  onChange={handleChange}
                />
                <input
                  type="time"
                  className="form-control mb-2"
                  name="hora"
                  value={modalMode === "crear" ? nuevaCita.hora : selectedCita?.hora}
                  onChange={handleChange}
                />
                <select
                  className="form-control mb-2"
                  name="consultorioId"
                  value={modalMode === "crear" ? nuevaCita.consultorioId : selectedCita?.consultorioId}
                  onChange={handleChange}
                >
                  <option value={0}>Seleccione un consultorio</option>
                  {consultorios.map(consultorio => (
                    <option key={consultorio.id} value={consultorio.id}>
                      {consultorio.numero} - Piso {consultorio.piso}
                    </option>
                  ))}
                </select>
              </div>
              <div className="modal-footer">
                <button className="btn btn-primary" onClick={handleSave}>Guardar</button>
                <button className="btn btn-secondary" onClick={() => setModalMode(null)}>Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE CONFIRMACIÓN PARA ELIMINAR */}
      {modalMode === "borrar" && selectedCita && (
        <div className="modal show d-block" tabIndex={-1} role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Eliminar Cita</h5>
                <button type="button" className="close" onClick={() => setModalMode(null)}>×</button>
              </div>
              <div className="modal-body">
                <p>¿Estás seguro de que deseas eliminar la cita con ID <strong>{selectedCita.id}</strong>?</p>
              </div>
              <div className="modal-footer">
                <button className="btn btn-danger" onClick={handleDelete}>Eliminar</button>
                <button className="btn btn-secondary" onClick={() => setModalMode(null)}>Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CitasPage;