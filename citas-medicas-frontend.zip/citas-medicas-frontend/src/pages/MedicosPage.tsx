import React, { FC, useState, useEffect } from 'react';
import { Plus, Edit, Trash } from 'lucide-react';

interface Medico {
  id: number;
  nombre: string;
  apellido: string;
  especialidad: string;
  email: string;
}

const MedicosPage: FC = () => {
  const [medicos, setMedicos] = useState<Medico[]>([]);
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState<Medico>({ id: 0, nombre: '', apellido: '', especialidad: '', email: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [isFormLoading, setIsFormLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchMedicos();
  }, []);

  const fetchMedicos = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('http://localhost:9090/api/medicos');
      const data: Medico[] = await response.json();
      setMedicos(data);
    } catch (err) {
      setError('Error al cargar los médicos. Intenta nuevamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpen = () => setOpen(true);
  const handleClose = () => {
    setFormData({ id: 0, nombre: '', apellido: '', especialidad: '', email: '' });
    setOpen(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    if (!formData.nombre || !formData.apellido || !formData.especialidad || !formData.email) {
      setError('Todos los campos son obligatorios');
      return;
    }
    setIsFormLoading(true);
    try {
      const method = formData.id ? 'PUT' : 'POST';
      const url = formData.id ? `http://localhost:9090/api/medicos/${formData.id}` : 'http://localhost:9090/api/medicos';
      await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      fetchMedicos();
      handleClose();
    } catch (err) {
      setError('Error al guardar el médico. Intenta nuevamente.');
    } finally {
      setIsFormLoading(false);
    }
  };

  const handleEdit = (medico: Medico) => {
    setFormData(medico);
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    try {
      setIsLoading(true);
      await fetch(`http://localhost:9090/api/medicos/${id}`, { method: 'DELETE' });
      fetchMedicos();
    } catch (err) {
      setError('Error al eliminar el médico. Intenta nuevamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container py-5">
      <h1 className="text-center mb-4">Gestión de Médicos</h1>
      <button className="btn btn-primary mb-4" onClick={handleOpen}>
        <Plus className="me-2" /> Crear Médico
      </button>

      {error && <div className="alert alert-danger">{error}</div>}

      {isLoading ? (
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Cargando...</span>
          </div>
        </div>
      ) : (
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
          {medicos.map((medico) => (
            <div key={medico.id} className="col">
              <div className="card shadow-sm">
                <div className="card-body">
                  <h5 className="card-title">{medico.nombre} {medico.apellido}</h5>
                  <p className="card-text"><strong>Especialidad:</strong> {medico.especialidad}</p>
                  <p className="card-text"><strong>Email:</strong> {medico.email}</p>
                  <div className="d-flex gap-2">
                    <button className="btn btn-success" onClick={() => handleEdit(medico)}>
                      <Edit className="h-4 w-4" />
                    </button>
                    <button className="btn btn-danger" onClick={() => handleDelete(medico.id)}>
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {open && (
        <div className="modal show d-block" tabIndex={-1}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{formData.id ? 'Editar Médico' : 'Crear Médico'}</h5>
                <button type="button" className="btn-close" onClick={handleClose}></button>
              </div>
              <div className="modal-body">
                <input type="text" className="form-control mb-2" name="nombre" placeholder="Nombre" value={formData.nombre} onChange={handleChange} />
                <input type="text" className="form-control mb-2" name="apellido" placeholder="Apellido" value={formData.apellido} onChange={handleChange} />
                <input type="text" className="form-control mb-2" name="especialidad" placeholder="Especialidad" value={formData.especialidad} onChange={handleChange} />
                <input type="email" className="form-control" name="email" placeholder="Email" value={formData.email} onChange={handleChange} />
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={handleClose}>Cancelar</button>
                <button className="btn btn-primary" onClick={handleSubmit} disabled={isFormLoading}>
                  {isFormLoading ? 'Guardando...' : 'Guardar'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MedicosPage;