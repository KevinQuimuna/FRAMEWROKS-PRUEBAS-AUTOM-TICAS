import React, { FC, useState, useEffect } from 'react';
import { Plus, Edit, Trash } from 'lucide-react';

interface Consultorio {
  id: number;
  numero: string;
  piso: number;
}

const ConsultoriosPage: FC = () => {
  const [consultorios, setConsultorios] = useState<Consultorio[]>([]);
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState<Consultorio>({ id: 0, numero: '', piso: 0 });
  const [isLoading, setIsLoading] = useState(false);
  const [isFormLoading, setIsFormLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchConsultorios();
  }, []);

  const fetchConsultorios = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('http://localhost:9090/api/consultorios');
      const data: Consultorio[] = await response.json();
      setConsultorios(data);
    } catch (err) {
      setError('Error al cargar los consultorios. Intenta nuevamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpen = () => setOpen(true);
  const handleClose = () => {
    setFormData({ id: 0, numero: '', piso: 0 });
    setOpen(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: name === 'piso' ? parseInt(value, 10) : value });
  };

  const handleSubmit = async () => {
    if (!formData.numero || formData.piso === undefined) {
      setError('Todos los campos son obligatorios');
      return;
    }
    setIsFormLoading(true);
    try {
      const method = formData.id ? 'PUT' : 'POST';
      const url = formData.id ? `http://localhost:9090/api/consultorios/${formData.id}` : 'http://localhost:9090/api/consultorios';
      await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      fetchConsultorios();
      handleClose();
    } catch (err) {
      setError('Error al guardar el consultorio. Intenta nuevamente.');
    } finally {
      setIsFormLoading(false);
    }
  };

  const handleEdit = (consultorio: Consultorio) => {
    setFormData(consultorio);
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    try {
      setIsLoading(true);
      await fetch(`http://localhost:9090/api/consultorios/${id}`, { method: 'DELETE' });
      fetchConsultorios();
    } catch (err) {
      setError('Error al eliminar el consultorio. Intenta nuevamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container py-5">
      <h1 className="text-center mb-4">Gestión de Consultorios</h1>
      <button className="btn btn-primary mb-4" onClick={handleOpen}>
        <Plus className="me-2" /> Crear Consultorio
      </button>

      {error && <div className="alert alert-danger">{error}</div>}

      {isLoading ? (
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Cargando...</span>
          </div>
        </div>
      ) : (
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
          {consultorios.map((consultorio) => (
            <div key={consultorio.id} className="col">
              <div className="card shadow-sm">
                <div className="card-body">
                  <h5 className="card-title">Consultorio {consultorio.numero}</h5>
                  <p className="card-text"><strong>Piso:</strong> {consultorio.piso}</p>
                  <div className="d-flex gap-2">
                    <button className="btn btn-success" onClick={() => handleEdit(consultorio)}>
                      <Edit className="h-4 w-4" />
                    </button>
                    <button className="btn btn-danger" onClick={() => handleDelete(consultorio.id)}>
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {open && (
        <div className="modal show d-block" tabIndex={-1}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{formData.id ? 'Editar Consultorio' : 'Crear Consultorio'}</h5>
                <button type="button" className="btn-close" onClick={handleClose}></button>
              </div>
              <div className="modal-body">
                <input type="text" className="form-control mb-2" name="numero" placeholder="Número" value={formData.numero} onChange={handleChange} />
                <input type="number" className="form-control" name="piso" placeholder="Piso" value={formData.piso} onChange={handleChange} />
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={handleClose}>Cancelar</button>
                <button className="btn btn-primary" onClick={handleSubmit} disabled={isFormLoading}>
                  {isFormLoading ? 'Guardando...' : 'Guardar'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConsultoriosPage;
