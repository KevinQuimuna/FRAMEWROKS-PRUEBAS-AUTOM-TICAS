package ec.edu.espe.Clinica.controller;

import ec.edu.espe.Clinica.entity.Cita;
import ec.edu.espe.Clinica.service.CitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/citas")
public class CitaController {

    @Autowired
    private CitaService citaService;

    @GetMapping
    public List<Cita> listarTodas() {
        return citaService.obtenerTodas();
    }

    @GetMapping("/{id}")
    public Optional<Cita> obtenerPorId(@PathVariable int id) {
        return citaService.obtenerPorId(id);
    }

    @PostMapping
    public Cita guardar(@RequestBody Cita cita) {
        return citaService.guardar(cita);
    }

    @PutMapping("/{id}")
    public Cita actualizar(@PathVariable int id, @RequestBody Cita cita) {
        cita.setId(id);
        return citaService.guardar(cita);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable int id) {
        citaService.eliminar(id);
    }
}
