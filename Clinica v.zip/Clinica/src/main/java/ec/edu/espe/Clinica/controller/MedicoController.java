package ec.edu.espe.Clinica.controller;

import ec.edu.espe.Clinica.entity.Medico;
import ec.edu.espe.Clinica.service.MedicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/medicos")
public class MedicoController {

    @Autowired
    private MedicoService medicoService;

    @GetMapping
    public List<Medico> listarTodos() {
        return medicoService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Optional<Medico> obtenerPorId(@PathVariable int id) {
        return medicoService.obtenerPorId(id);
    }

    @PostMapping
    public Medico guardar(@RequestBody Medico medico) {
        return medicoService.guardar(medico);
    }

    @PutMapping("/{id}")
    public Medico actualizar(@PathVariable int id, @RequestBody Medico medico) {
        medico.setId(id);
        return medicoService.guardar(medico);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable int id) {
        medicoService.eliminar(id);
    }
}
