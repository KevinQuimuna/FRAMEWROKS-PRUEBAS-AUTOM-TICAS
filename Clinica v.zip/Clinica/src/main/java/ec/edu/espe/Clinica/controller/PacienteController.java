package ec.edu.espe.Clinica.controller;


import ec.edu.espe.Clinica.entity.Paciente;
import ec.edu.espe.Clinica.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService pacienteService;

    @GetMapping
    public List<Paciente> listarTodos() {
        return pacienteService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Optional<Paciente> obtenerPorId(@PathVariable int id) {
        return pacienteService.obtenerPorId(id);
    }

    @PostMapping
    public Paciente guardar(@RequestBody Paciente paciente) {
        return pacienteService.guardar(paciente);
    }

    @PutMapping("/{id}")
    public Paciente actualizar(@PathVariable int id, @RequestBody Paciente paciente) {
        paciente.setId(id);
        return pacienteService.guardar(paciente);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable int id) {
        pacienteService.eliminar(id);
    }
}
