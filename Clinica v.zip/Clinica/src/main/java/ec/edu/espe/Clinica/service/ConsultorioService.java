package ec.edu.espe.Clinica.service;


import ec.edu.espe.Clinica.entity.Consultorio;
import ec.edu.espe.Clinica.repository.ConsultorioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ConsultorioService {

    @Autowired
    private ConsultorioRepository consultorioRepository;

    public List<Consultorio> obtenerTodos() {
        return consultorioRepository.findAll();
    }

    public Optional<Consultorio> obtenerPorId(int id) {
        return consultorioRepository.findById(id);
    }

    public Consultorio guardar(Consultorio consultorio) {
        return consultorioRepository.save(consultorio);
    }

    public void eliminar(int id) {
        consultorioRepository.deleteById(id);
    }
}
