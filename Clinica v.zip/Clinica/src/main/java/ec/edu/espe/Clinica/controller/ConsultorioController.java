package ec.edu.espe.Clinica.controller;


import ec.edu.espe.Clinica.entity.Consultorio;
import ec.edu.espe.Clinica.service.ConsultorioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/consultorios")
public class ConsultorioController {

    @Autowired
    private ConsultorioService consultorioService;

    @GetMapping
    public List<Consultorio> listarTodos() {
        return consultorioService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Optional<Consultorio> obtenerPorId(@PathVariable int id) {
        return consultorioService.obtenerPorId(id);
    }

    @PostMapping
    public Consultorio guardar(@RequestBody Consultorio consultorio) {
        return consultorioService.guardar(consultorio);
    }

    @PutMapping("/{id}")
    public Consultorio actualizar(@PathVariable int id, @RequestBody Consultorio consultorio) {
        consultorio.setId(id);
        return consultorioService.guardar(consultorio);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable int id) {
        consultorioService.eliminar(id);
    }
}

